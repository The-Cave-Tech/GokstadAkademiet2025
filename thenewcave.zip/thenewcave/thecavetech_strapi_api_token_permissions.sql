-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `strapi_api_token_permissions`
--

DROP TABLE IF EXISTS `strapi_api_token_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `strapi_api_token_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `document_id` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `strapi_api_token_permissions_documents_idx` (`document_id`,`locale`,`published_at`),
  KEY `strapi_api_token_permissions_created_by_id_fk` (`created_by_id`),
  KEY `strapi_api_token_permissions_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `strapi_api_token_permissions_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `strapi_api_token_permissions_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strapi_api_token_permissions`
--

LOCK TABLES `strapi_api_token_permissions` WRITE;
/*!40000 ALTER TABLE `strapi_api_token_permissions` DISABLE KEYS */;
INSERT INTO `strapi_api_token_permissions` VALUES (7,'o17ql34phe68qgfwpl0zlfju','plugin::users-permissions.auth.callback','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.038000',NULL,NULL,NULL),(8,'bl1mj7ytztnhh85ms25l5nur','plugin::users-permissions.auth.changePassword','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(9,'p99q6jkhym8nc0ej5pc9vjyl','plugin::users-permissions.auth.resetPassword','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(10,'dzdndazkq4grus79rybx9drq','plugin::users-permissions.auth.connect','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(11,'sn7kzpuw6lj17lpog9azq4o5','plugin::users-permissions.auth.forgotPassword','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(12,'fgpvlgfx4jds5v17i9m3u415','plugin::users-permissions.auth.register','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(13,'f233748yfj6cdenwph6qcmox','plugin::users-permissions.auth.emailConfirmation','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(14,'rf53m2t56omz9ydz34wr0ahm','plugin::users-permissions.auth.sendEmailConfirmation','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.039000',NULL,NULL,NULL),(15,'ld4e7mwiymqs6onogjwlue3x','plugin::users-permissions.user.create','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(16,'c3sc24pgea22xbajzr79l42e','plugin::users-permissions.user.update','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(17,'h57mywzsw6sphvqbarl59rup','plugin::users-permissions.user.find','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(18,'ondu1fs0q3jki3qcm1a0hfbf','plugin::users-permissions.user.findOne','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(19,'jnmz9fsub9jo1goi819mk64x','plugin::users-permissions.user.count','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(20,'jdarmjcgugttb2197d39acko','plugin::users-permissions.user.destroy','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(21,'keer1bmp14ib3acng21xts1n','plugin::users-permissions.user.me','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(22,'hem3xgrvco4mcfl0crnpu4p6','plugin::users-permissions.role.createRole','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(23,'g9vgdwyy0z3yskd5w600yt59','plugin::users-permissions.role.findOne','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(24,'y1buhfn7bb5vtrunl4810180','plugin::users-permissions.role.find','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(25,'qyo0vif30onnc2rb8le2xpwa','plugin::users-permissions.role.updateRole','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(26,'wxv2h5pk49bv9qlgb3l3d1wy','plugin::users-permissions.role.deleteRole','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(27,'ijrensdbtaxgiab73d0qqjk7','plugin::users-permissions.permissions.getPermissions','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(28,'j6pp0gzgna1a0m8dmx1f5v1o','plugin::i18n.locales.listLocales','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(29,'ggaa7867ifahzrcx2x6oyhid','plugin::upload.content-api.find','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(30,'xbyjaupf08iu8dsfroxcu2jq','plugin::upload.content-api.findOne','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.040000',NULL,NULL,NULL),(31,'k5ngswox5lpuetzehiitemta','plugin::upload.content-api.destroy','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.041000',NULL,NULL,NULL),(32,'ktucuwz4irlohmuax5swl76m','plugin::upload.content-api.upload','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.041000',NULL,NULL,NULL),(33,'qo2sk2anxgv3wuhvpkquhezm','plugin::email.email.send','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.041000',NULL,NULL,NULL),(34,'iudyyr8124hjcduptzs01trj','plugin::content-type-builder.components.getComponents','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.041000',NULL,NULL,NULL),(35,'z0hc4pd0la8c5r4sefcnzmin','plugin::content-type-builder.components.getComponent','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.041000',NULL,NULL,NULL),(36,'iq8x8ujmo9hfyxcrlll9ea3e','plugin::content-type-builder.content-types.getContentTypes','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.042000',NULL,NULL,NULL),(37,'rxvrs9s497nkjdpn63izldgc','plugin::content-type-builder.content-types.getContentType','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.037000','2025-03-04 21:38:42.042000',NULL,NULL,NULL);
/*!40000 ALTER TABLE `strapi_api_token_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:20
