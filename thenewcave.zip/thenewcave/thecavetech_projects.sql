-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `document_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` longtext,
  `description` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `technologies` json DEFAULT NULL,
  `demo_url` varchar(255) DEFAULT NULL,
  `github_url` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projects_documents_idx` (`document_id`,`locale`,`published_at`),
  KEY `projects_created_by_id_fk` (`created_by_id`),
  KEY `projects_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `projects_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `projects_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'mrui8m7p6x0cw3808yvdo9dv','Smart Plantevokter 3000','**Bold**\nGrunnleggende programmering\n\nElektronikk (sensorer, kretsløp)\n\nBærekraft og miljøbevissthet\n\n','Et prosjekt der deltakerne bygger en enhet med en fuktighetssensor, lysmåler og en liten vannpumpe styrt av en Arduino eller Raspberry Pi. Når jorda er tørr, vannes planten automatisk.','complete',NULL,'assa','sasa','asas','2025-05-09 21:04:08.932000','2025-05-09 21:04:08.932000',NULL,1,1,NULL),(2,'mrui8m7p6x0cw3808yvdo9dv','Smart Plantevokter 3000','**Bold**\nGrunnleggende programmering\n\nElektronikk (sensorer, kretsløp)\n\nBærekraft og miljøbevissthet\n\n','Et prosjekt der deltakerne bygger en enhet med en fuktighetssensor, lysmåler og en liten vannpumpe styrt av en Arduino eller Raspberry Pi. Når jorda er tørr, vannes planten automatisk.','complete',NULL,'assa','sasa','asas','2025-05-09 21:04:08.932000','2025-05-09 21:04:08.932000','2025-05-09 21:04:08.972000',1,1,NULL),(3,'bp260yp76ymmfv090vcu7iyr','DIY Mini-Arkademaskin','![pexels-mateus-zierke-181574549-11552325.jpg](http://localhost:1337/uploads/pexels_mateus_zierke_181574549_11552325_240463066a.jpg)\n\n\nHusker du lyden av gamle 8-bit spill og følelsen av å spille Pac-Man i mørke arkadehaller? Nå kan du bygge din egen mini-arkademaskin – og gjenoppleve den magien, samtidig som du lærer om teknologi!\n\nDette maker space-prosjektet tar deltakerne med inn i både design og teknologi. Ved hjelp av en Raspberry Pi, knapper, en liten LCD-skjerm og kabinett laget med 3D-printer eller laserskjærer, skaper man en fullt funksjonell retrospillkonsoll.\n\nDu lærer:\n\nHvordan installere RetroPie og bruke emulering\n\nLoddeteknikk for knappekoblinger\n\nHvordan designe og bygge egne kabinetter\n\nResultatet er ikke bare en stilig maskin – det er en portal til fortiden, bygget med morgendagens teknologi. Perfekt for workshops, ungdomsaktiviteter eller bare ren nerdelykke.\n\n![pexels-christian-heitz-285904-842711.jpg](http://localhost:1337/uploads/pexels_christian_heitz_285904_842711_11436379a5.jpg)','En nostalgisk reise inn i kodingens verden','complete',NULL,'ssasas','asas','asasas','2025-05-09 21:06:41.860000','2025-05-09 21:07:06.208000',NULL,1,1,NULL),(5,'bp260yp76ymmfv090vcu7iyr','DIY Mini-Arkademaskin','![pexels-mateus-zierke-181574549-11552325.jpg](http://localhost:1337/uploads/pexels_mateus_zierke_181574549_11552325_240463066a.jpg)\n\n\nHusker du lyden av gamle 8-bit spill og følelsen av å spille Pac-Man i mørke arkadehaller? Nå kan du bygge din egen mini-arkademaskin – og gjenoppleve den magien, samtidig som du lærer om teknologi!\n\nDette maker space-prosjektet tar deltakerne med inn i både design og teknologi. Ved hjelp av en Raspberry Pi, knapper, en liten LCD-skjerm og kabinett laget med 3D-printer eller laserskjærer, skaper man en fullt funksjonell retrospillkonsoll.\n\nDu lærer:\n\nHvordan installere RetroPie og bruke emulering\n\nLoddeteknikk for knappekoblinger\n\nHvordan designe og bygge egne kabinetter\n\nResultatet er ikke bare en stilig maskin – det er en portal til fortiden, bygget med morgendagens teknologi. Perfekt for workshops, ungdomsaktiviteter eller bare ren nerdelykke.\n\n![pexels-christian-heitz-285904-842711.jpg](http://localhost:1337/uploads/pexels_christian_heitz_285904_842711_11436379a5.jpg)','En nostalgisk reise inn i kodingens verden','complete',NULL,'ssasas','asas','asasas','2025-05-09 21:06:41.860000','2025-05-09 21:07:06.208000','2025-05-09 21:07:06.227000',1,1,NULL),(6,'p0o0n29bo18l4jiundmql56t','Plug-and-Play Nettverksautomasjon','<p>Utviklet plug-and-play nettverksautomasjon for skoleprosjekter og praktisk IT-læring.</p><p></p><p></p>','','complete','[\"Ansible\", \"Cisco\"]','https://github.com/The-Cave-Tech/Network-PnP','https://github.com/The-Cave-Tech/Network-PnP','Nettverk','2025-05-09 21:08:35.104000','2025-05-11 17:03:57.002000',NULL,1,1,NULL),(9,'p0o0n29bo18l4jiundmql56t','Plug-and-Play Nettverksautomasjon','<p>Utviklet plug-and-play nettverksautomasjon for skoleprosjekter og praktisk IT-læring.</p><p></p><p></p>','','complete','[\"Ansible\", \"Cisco\"]','https://github.com/The-Cave-Tech/Network-PnP','https://github.com/The-Cave-Tech/Network-PnP','Nettverk','2025-05-09 21:08:35.104000','2025-05-11 17:03:57.002000','2025-05-11 17:03:57.026000',1,1,NULL),(10,'rgtyu5k2wclhh2u312vwz1zl','Netbox All-in-One','<p>Installation</p><p>NetBox is a difficult environment to spin up. We\'re simplifying it so any computer running Ubuntu Server 22.04 LTS (even a Raspberry Pi) can be installed and configured with a fully operational NetBox environment. Currently, this is based on qemu/kvm, later versions will be based on Linux Containers.</p>','','complete','[]','','','Other','2025-05-11 17:07:09.433000','2025-05-11 17:07:09.433000',NULL,NULL,NULL,NULL),(11,'rgtyu5k2wclhh2u312vwz1zl','Netbox All-in-One','<p>Installation</p><p>NetBox is a difficult environment to spin up. We\'re simplifying it so any computer running Ubuntu Server 22.04 LTS (even a Raspberry Pi) can be installed and configured with a fully operational NetBox environment. Currently, this is based on qemu/kvm, later versions will be based on Linux Containers.</p>','','complete','[]','','','Other','2025-05-11 17:07:09.433000','2025-05-11 17:07:09.433000','2025-05-11 17:07:09.444000',NULL,NULL,NULL),(14,'c1yylvpignm5hg75q5o84n3z','Ansible','<p>Ansible Redhat</p>','','complete','[]','','','Other','2025-05-11 17:08:37.922000','2025-05-11 17:08:37.922000',NULL,NULL,NULL,NULL),(15,'c1yylvpignm5hg75q5o84n3z','Ansible','<p>Ansible Redhat</p>','','complete','[]','','','Other','2025-05-11 17:08:37.922000','2025-05-11 17:08:37.922000','2025-05-11 17:08:37.932000',NULL,NULL,NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:20
