-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files_related_mph`
--

DROP TABLE IF EXISTS `files_related_mph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files_related_mph` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_id` int unsigned DEFAULT NULL,
  `related_id` int unsigned DEFAULT NULL,
  `related_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` double unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_related_mph_fk` (`file_id`),
  KEY `files_related_mph_oidx` (`order`),
  KEY `files_related_mph_idix` (`related_id`),
  CONSTRAINT `files_related_mph_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=507 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files_related_mph`
--

LOCK TABLES `files_related_mph` WRITE;
/*!40000 ALTER TABLE `files_related_mph` DISABLE KEYS */;
INSERT INTO `files_related_mph` VALUES (440,129,17,'api::landing-page.landing-page','IntroductionImage',1),(441,130,1,'api::auth-setting.auth-setting','AuthBackgroundImage',1),(442,130,6,'api::auth-setting.auth-setting','AuthBackgroundImage',1),(445,131,1,'footer.social-media','icon',1),(446,132,1,'footer.social-links','icon',1),(447,131,3,'footer.social-media','icon',1),(448,132,2,'footer.social-links','icon',1),(454,129,18,'api::landing-page.landing-page','IntroductionImage',1),(457,134,19,'landing-page.hero-section','landingImage',1),(458,135,19,'api::landing-page.landing-page','IntroductionImage',1),(463,135,21,'landing-page.hero-section','heroImage',1),(465,134,1,'landing-page.hero-section','landingImage',1),(466,135,1,'api::landing-page.landing-page','IntroductionImage',1),(467,134,22,'landing-page.hero-section','landingImage',1),(468,135,22,'api::landing-page.landing-page','IntroductionImage',1),(485,134,1,'api::project.project','projectImage',1),(486,134,2,'api::project.project','projectImage',1),(487,133,3,'api::project.project','projectImage',1),(488,133,5,'api::project.project','projectImage',1),(489,132,6,'api::project.project','projectImage',1),(491,134,1,'api::product.product','productImage',1),(492,134,2,'api::product.product','productImage',1),(493,132,1,'aboutus.history','Image',1),(494,135,1,'aboutus.gallery','image',1),(495,132,2,'aboutus.history','Image',1),(496,135,2,'aboutus.gallery','image',1),(497,136,1,'api::global-setting.global-setting','SiteLogo',1),(498,136,14,'api::global-setting.global-setting','SiteLogo',1),(501,135,1,'landing-page.hero-section','heroImage',1),(502,134,1,'landing-page.intro','introductionImage',1),(503,135,27,'landing-page.hero-section','heroImage',1),(504,134,6,'landing-page.intro','introductionImage',1),(506,132,9,'api::project.project','projectImage',1);
/*!40000 ALTER TABLE `files_related_mph` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:20
