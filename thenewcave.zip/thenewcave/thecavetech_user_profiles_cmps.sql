-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_profiles_cmps`
--

DROP TABLE IF EXISTS `user_profiles_cmps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles_cmps` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int unsigned DEFAULT NULL,
  `cmp_id` int unsigned DEFAULT NULL,
  `component_type` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `order` double unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_profiles_uq` (`entity_id`,`cmp_id`,`field`,`component_type`),
  KEY `user_profiles_field_idx` (`field`),
  KEY `user_profiles_component_type_idx` (`component_type`),
  KEY `user_profiles_entity_fk` (`entity_id`),
  CONSTRAINT `user_profiles_entity_fk` FOREIGN KEY (`entity_id`) REFERENCES `user_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles_cmps`
--

LOCK TABLES `user_profiles_cmps` WRITE;
/*!40000 ALTER TABLE `user_profiles_cmps` DISABLE KEYS */;
INSERT INTO `user_profiles_cmps` VALUES (226,40,40,'user-profile.public-profile','publicProfile',NULL),(227,40,40,'user-profile.personal-information','personalInformation',NULL),(228,40,40,'user-profile.notification-settings','notificationSettings',NULL),(229,40,40,'user-profile.account-administration','accountAdministration',NULL),(230,41,41,'user-profile.public-profile','publicProfile',NULL),(231,41,41,'user-profile.personal-information','personalInformation',NULL),(232,41,41,'user-profile.notification-settings','notificationSettings',NULL),(233,41,41,'user-profile.account-administration','accountAdministration',NULL),(246,45,45,'user-profile.public-profile','publicProfile',NULL),(247,45,45,'user-profile.personal-information','personalInformation',NULL),(248,45,45,'user-profile.notification-settings','notificationSettings',NULL),(249,45,45,'user-profile.account-administration','accountAdministration',NULL),(250,46,46,'user-profile.public-profile','publicProfile',NULL),(251,46,46,'user-profile.personal-information','personalInformation',NULL),(252,46,46,'user-profile.notification-settings','notificationSettings',NULL),(253,46,46,'user-profile.account-administration','accountAdministration',NULL);
/*!40000 ALTER TABLE `user_profiles_cmps` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:20
