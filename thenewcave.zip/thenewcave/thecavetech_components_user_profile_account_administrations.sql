-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_user_profile_account_administrations`
--

DROP TABLE IF EXISTS `components_user_profile_account_administrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_user_profile_account_administrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account_active` tinyint(1) DEFAULT NULL,
  `account_creation_date` datetime(6) DEFAULT NULL,
  `last_login_date` datetime(6) DEFAULT NULL,
  `deletion_reason` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_user_profile_account_administrations`
--

LOCK TABLES `components_user_profile_account_administrations` WRITE;
/*!40000 ALTER TABLE `components_user_profile_account_administrations` DISABLE KEYS */;
INSERT INTO `components_user_profile_account_administrations` VALUES (1,1,'2025-05-06 16:06:16.297000',NULL,NULL),(2,1,'2025-05-06 16:48:14.608000',NULL,NULL),(3,1,'2025-05-06 17:22:49.963000',NULL,NULL),(20,1,'2025-05-09 00:52:07.905000',NULL,NULL),(22,1,'2025-05-09 02:14:17.659000',NULL,NULL),(23,1,'2025-05-09 08:22:26.894000',NULL,NULL),(24,1,'2025-05-09 08:31:23.282000',NULL,NULL),(25,1,'2025-05-09 08:32:16.800000',NULL,NULL),(26,1,'2025-05-09 08:50:39.516000',NULL,NULL),(27,1,'2025-05-09 08:59:52.551000',NULL,NULL),(28,1,'2025-05-09 09:01:35.114000',NULL,NULL),(29,1,'2025-05-09 09:11:55.531000',NULL,NULL),(30,1,'2025-05-09 09:14:07.603000',NULL,NULL),(31,1,'2025-05-09 09:24:34.501000',NULL,NULL),(32,1,'2025-05-09 09:27:26.020000',NULL,NULL),(33,1,'2025-05-09 09:31:40.348000',NULL,NULL),(34,1,'2025-05-09 09:44:11.515000',NULL,NULL),(35,1,'2025-05-09 09:55:41.204000',NULL,NULL),(37,1,'2025-05-09 10:00:49.217000',NULL,NULL),(38,1,'2025-05-09 10:03:48.586000',NULL,NULL),(39,1,'2025-05-09 13:15:14.375000',NULL,NULL),(40,1,'2025-05-09 13:15:49.260000',NULL,NULL),(41,1,'2025-05-09 23:26:31.615000',NULL,NULL),(45,1,'2025-05-10 01:50:52.662000',NULL,NULL),(46,1,'2025-05-10 12:26:24.500000',NULL,NULL);
/*!40000 ALTER TABLE `components_user_profile_account_administrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:21
