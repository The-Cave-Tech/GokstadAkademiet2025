-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_user_profile_personal_informations`
--

DROP TABLE IF EXISTS `components_user_profile_personal_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_user_profile_personal_informations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `street_address` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_user_profile_personal_informations`
--

LOCK TABLES `components_user_profile_personal_informations` WRITE;
/*!40000 ALTER TABLE `components_user_profile_personal_informations` DISABLE KEYS */;
INSERT INTO `components_user_profile_personal_informations` VALUES (1,'Elisabeth','2024-05-08','Kvinne','+47 333 33 333','Oslogate',NULL,NULL),(2,'',NULL,NULL,NULL,NULL,NULL,NULL),(3,'Simen Skolen','2006-05-19','Mann','+47 333 33 333','Notteden gatanna','9090','Oslo'),(20,'',NULL,NULL,NULL,NULL,NULL,NULL),(22,'',NULL,NULL,NULL,NULL,NULL,NULL),(23,'',NULL,NULL,NULL,NULL,NULL,NULL),(24,'',NULL,NULL,NULL,NULL,NULL,NULL),(25,'',NULL,NULL,NULL,NULL,NULL,NULL),(26,'',NULL,NULL,NULL,NULL,NULL,NULL),(27,'',NULL,NULL,NULL,NULL,NULL,NULL),(28,'',NULL,NULL,NULL,NULL,NULL,NULL),(29,'',NULL,NULL,NULL,NULL,NULL,NULL),(30,'',NULL,NULL,NULL,NULL,NULL,NULL),(31,'',NULL,NULL,NULL,NULL,NULL,NULL),(32,'',NULL,NULL,NULL,NULL,NULL,NULL),(33,'',NULL,NULL,NULL,NULL,NULL,NULL),(34,'',NULL,NULL,NULL,NULL,NULL,NULL),(35,'',NULL,NULL,NULL,NULL,NULL,NULL),(37,'',NULL,NULL,NULL,NULL,NULL,NULL),(38,'',NULL,NULL,NULL,NULL,NULL,NULL),(39,'',NULL,NULL,NULL,NULL,NULL,NULL),(40,'',NULL,NULL,NULL,NULL,NULL,NULL),(41,'',NULL,NULL,NULL,NULL,NULL,NULL),(45,'',NULL,NULL,NULL,NULL,NULL,NULL),(46,'',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `components_user_profile_personal_informations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:21
