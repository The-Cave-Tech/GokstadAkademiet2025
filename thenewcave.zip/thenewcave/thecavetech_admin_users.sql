-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `document_id` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `registration_token` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `blocked` tinyint(1) DEFAULT NULL,
  `prefered_language` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `published_at` datetime(6) DEFAULT NULL,
  `created_by_id` int unsigned DEFAULT NULL,
  `updated_by_id` int unsigned DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_users_documents_idx` (`document_id`,`locale`,`published_at`),
  KEY `admin_users_created_by_id_fk` (`created_by_id`),
  KEY `admin_users_updated_by_id_fk` (`updated_by_id`),
  CONSTRAINT `admin_users_created_by_id_fk` FOREIGN KEY (`created_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `admin_users_updated_by_id_fk` FOREIGN KEY (`updated_by_id`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'qjsz2r2cn7a9kz9vfk9u7rcu','adam','maltsagov',NULL,'adam01@live.no','$2a$10$90ruF6CzX1u9yWTkiZBjheRpAEFwkYmEx06InIhrkFBw.JBuiNSxy',NULL,NULL,1,0,NULL,'2025-02-27 20:44:59.768000','2025-05-07 19:08:08.110000','2025-02-27 20:44:59.769000',NULL,NULL,NULL),(2,'vyrj2gqtygkni897at4bfb97','Simen','Skogen',NULL,'sim1skogen@gmail.com','$2a$10$ITrtvkBRhOwuOTBy5Dun8.NqJLs0HnXboPl2cXpBtM4.IhBN5c3zG',NULL,NULL,1,0,NULL,'2025-02-28 12:32:47.355000','2025-02-28 12:33:13.921000','2025-02-28 12:32:47.359000',NULL,NULL,NULL),(3,'uosuvvxafvoltnr5h82qkkg3','Aslan','Khatuev',NULL,'test@test.no','$2a$10$LYOGlf8ICWrZEnlOJ94et.qTW3HHyTvDtOFvVzdBiwXEDPJvhZKxS',NULL,NULL,1,0,NULL,'2025-02-28 12:34:29.768000','2025-04-26 02:50:18.507000','2025-02-28 12:34:29.770000',NULL,NULL,NULL),(4,'rcdas3btetfxcyxc1fau6xze','Bendikk','Bror',NULL,'bendik@bror.no','$2a$10$MbVHfqeZLNduPihRgSMf3uW0O9c.Ze8VlG8mG.Y2huHyGf06DoCKq',NULL,NULL,1,0,NULL,'2025-02-28 12:35:37.082000','2025-02-28 12:35:53.810000','2025-02-28 12:35:37.083000',NULL,NULL,NULL),(5,'b5l7nwiqj2zhyqsua9a75e8d','Darren','Star',NULL,'darren.star@cavtech.no','$2a$10$iBvmybmAiXaNmsCACM4iGODjE.NbKwwi7Jw4yRFqSDUSql9LuM65O',NULL,NULL,1,0,NULL,'2025-02-28 14:19:39.846000','2025-02-28 14:20:09.389000','2025-02-28 14:19:39.847000',NULL,NULL,NULL),(6,'ussi72fp4anlmcn6nwiw2sj6','Test','Den',NULL,'test@den.no','$2a$10$xJOuThfjbV.ec5IOhu0I0OyHfawoW7MsEQdSNus6ZSpAWKfzTUbdW',NULL,'17731f105f2433562be0e1dbb3fa593fc492cd2b',0,0,NULL,'2025-02-28 19:39:33.524000','2025-02-28 19:39:52.752000','2025-02-28 19:39:33.527000',NULL,NULL,NULL);
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:18
