-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_user_profile_public_profiles`
--

DROP TABLE IF EXISTS `components_user_profile_public_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_user_profile_public_profiles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `biography` longtext,
  `show_email` tinyint(1) DEFAULT NULL,
  `show_phone` tinyint(1) DEFAULT NULL,
  `show_address` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_user_profile_public_profiles`
--

LOCK TABLES `components_user_profile_public_profiles` WRITE;
/*!40000 ALTER TABLE `components_user_profile_public_profiles` DISABLE KEYS */;
INSERT INTO `components_user_profile_public_profiles` VALUES (1,'Elisabeth','Jeg liker å designe!!!',1,1,1),(2,'adam91','ASDsadsadsadsaddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddASDsadsadsadsaddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddASDsadsadsadsaddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddASDsadsadsadsadddddddddddddddddddd',0,0,0),(3,'Simen ','Jeg vil spille asiatisk spill!!!!!!!!!!!',1,1,1),(20,'Adam Vuso','',0,0,0),(22,'Adam Vuso','',0,0,0),(23,'Adam Vuso','',0,0,0),(24,'Adam Vuso','',0,0,0),(25,'Adam Vuso','',0,0,0),(26,'maad1006','',0,0,0),(27,'maad1006','',0,0,0),(28,'maad1006','',0,0,0),(29,'maad1006','',0,0,0),(30,'maad1006','',0,0,0),(31,'maad1006','',0,0,0),(32,'test91','',0,0,0),(33,'maad1006','',0,0,0),(34,'maad1006','',0,0,0),(35,'maad1006','',0,0,0),(37,'Test91','',0,0,0),(38,'maad1006','',0,0,0),(39,'maad1006','',0,0,0),(40,'Adam Vuso','',0,0,0),(41,'maad1006','',0,0,0),(45,'testuser','',0,0,0),(46,'test91','',0,0,0);
/*!40000 ALTER TABLE `components_user_profile_public_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:18
