-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: thecavetech
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `components_landing_page_intros`
--

DROP TABLE IF EXISTS `components_landing_page_intros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `components_landing_page_intros` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `introduction_text` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `components_landing_page_intros`
--

LOCK TABLES `components_landing_page_intros` WRITE;
/*!40000 ALTER TABLE `components_landing_page_intros` DISABLE KEYS */;
INSERT INTO `components_landing_page_intros` VALUES (1,'Introduksjon','Cavetech er et høyteknologisk skaperverksted og et fellesskap for mennesker som deler felles lidenskap og interesser. \nVi er et lukket miljø basert på tillit og felles lidenskap, der man blir en del av gjengen gjennom invitasjon. All innsats og støtte går tilbake til fellesskapet - i form av utstyr, kunnskap og åpne prosjekter. \nIkke for profitt, men for vekst, skaperglede og mennesker som blomstrer sammen og gi noe tilbake.\n\nVi tror på \"low effort, high impact\": \nå skape ting som falles ut naturlig!\n\nNoe vi har fått til så langt: \n\n- Utviklet plug-and-play nettverksautomasjon for skoleprosjekter og praktisk IT-læring.\n- Designet og sydd en brudekjole, brodert bunadsdetaljer og laget hårstrikk og bryllupspynt. \n- Bidratt til 2 fullførte CCNA-sertifiseringer og hjulpet 2 personer ut i jobb.\n- Gjennomførte fotoshoot i Roma med egne design.\n- Laget bærekraftig og fleksibel innredning av gjenbruksmaterialer.\n- Startet egen instagram og nettside for å vise frem og dele kunnskap og muligheter for å selge ting vi lager\n- Skapt og tilpasset korsett'),(6,'Introduksjon','Cavetech er et høyteknologisk skaperverksted og et fellesskap for mennesker som deler felles lidenskap og interesser. \nVi er et lukket miljø basert på tillit og felles lidenskap, der man blir en del av gjengen gjennom invitasjon. All innsats og støtte går tilbake til fellesskapet - i form av utstyr, kunnskap og åpne prosjekter. \nIkke for profitt, men for vekst, skaperglede og mennesker som blomstrer sammen og gi noe tilbake.\n\nVi tror på \"low effort, high impact\": \nå skape ting som falles ut naturlig!\n\nNoe vi har fått til så langt: \n\n- Utviklet plug-and-play nettverksautomasjon for skoleprosjekter og praktisk IT-læring.\n- Designet og sydd en brudekjole, brodert bunadsdetaljer og laget hårstrikk og bryllupspynt. \n- Bidratt til 2 fullførte CCNA-sertifiseringer og hjulpet 2 personer ut i jobb.\n- Gjennomførte fotoshoot i Roma med egne design.\n- Laget bærekraftig og fleksibel innredning av gjenbruksmaterialer.\n- Startet egen instagram og nettside for å vise frem og dele kunnskap og muligheter for å selge ting vi lager\n- Skapt og tilpasset korsett');
/*!40000 ALTER TABLE `components_landing_page_intros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 17:27:20
